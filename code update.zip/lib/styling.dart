import 'package:flutter/material.dart';

const orange = Colors.orangeAccent;
const black = Colors.black;
const grey = Colors.grey;
const white = Colors.white;
const red = Colors.red;
const green = Colors.green;
